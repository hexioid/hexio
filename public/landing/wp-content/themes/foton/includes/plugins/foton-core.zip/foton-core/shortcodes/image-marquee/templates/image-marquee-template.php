<div class="mkdf-image-marquee-holder">
    <div class="mkdf-image-marquee">
        <div class="mkdf-image mkdf-original">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
        <div class="mkdf-image mkdf-aux">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
    </div>
</div>